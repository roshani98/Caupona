<?php
	$conn = mysqli_connect("localhost","id402309_caupona","cauponacaupona","id402309_caupona");
?>