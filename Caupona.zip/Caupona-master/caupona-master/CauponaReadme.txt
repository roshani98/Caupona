BASE WEBSITE: http://codeword.000webhostapp.com/
GITHUB: https://github.com/vasanimit9/caupona
MANAGER SITE: http://codeword.000webhostapp.com/manager.php and http://codeword.000webhostapp.com/?m=1&r=2&app=1
CUSTOMER SITE: http://codeword.000webhostapp.com/?r=2&t=2&u=hey@gmail.com&app=0
